names_pack <- c('nmw')
install.packages(names_pack, lib = './Rlib')
update.packages(names_pack, lib = './Rlib')
